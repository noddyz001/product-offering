package com.productoffering;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductOfferingApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductOfferingApplication.class, args);
	}

}
